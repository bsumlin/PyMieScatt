1.6.0a - See `documentation <http://pymiescatt.readthedocs.io/>`_ for update notes.


