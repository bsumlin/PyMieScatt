1.1.0 - Added a dispersion feature to MieQ_withWavelengthRange.
Added links to documentation in source code. Docs are hosted at `ReadTheDocs <http://pymiescatt.readthedocs.io/>`_.

