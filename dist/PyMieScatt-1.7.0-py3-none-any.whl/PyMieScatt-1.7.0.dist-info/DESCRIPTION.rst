1.7.0 - See `documentation <http://pymiescatt.readthedocs.io/>`_ for update notes.


