1.2.5 - Added error bounds as an option for the graphical inversion method. Added new automatic inversion methods Inversion() and Inversion_SD(). Significantly improved the iterative methods.
Docs are hosted at `ReadTheDocs <http://pymiescatt.readthedocs.io/>`_.

