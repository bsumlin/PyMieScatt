1.0.1 - considerably refactored and commented code to be more human-readable. Added a graphical inversion method.


