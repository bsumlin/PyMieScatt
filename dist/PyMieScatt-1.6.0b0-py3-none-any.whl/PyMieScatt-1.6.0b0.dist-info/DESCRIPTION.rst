1.6.0b - See `documentation <http://pymiescatt.readthedocs.io/>`_ for update notes.


