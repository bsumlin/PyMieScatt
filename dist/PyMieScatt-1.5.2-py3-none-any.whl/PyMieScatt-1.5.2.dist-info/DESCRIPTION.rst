1.5.2 - See `documentation <http://pymiescatt.readthedocs.io/>`_ for update notes.


