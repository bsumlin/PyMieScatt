1.0.3 - Code base is complete. More features will be added in the future that build upon existing code.
Added links to documentation in source code. Docs are hosted at `ReadTheDocs <http://pymiescatt.readthedocs.io/>`_

