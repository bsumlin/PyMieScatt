1.1.2 - Added error bounds as an option for the graphical inversion method. 
Docs are hosted at `ReadTheDocs <http://pymiescatt.readthedocs.io/>`_.

